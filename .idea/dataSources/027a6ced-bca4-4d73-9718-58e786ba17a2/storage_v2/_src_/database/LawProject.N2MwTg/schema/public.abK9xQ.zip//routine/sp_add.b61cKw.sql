create procedure sp_add(relativ_menu integer, direct integer, name_menu character varying)
    language plpgsql
as
$$
DECLARE
relativ_menu_ord int;
relativ_menu_dep int;
BEGIN
    IF direct=0 THEN
		relativ_menu_ord = relativ_menu;
		relativ_menu_dep = (SELECT dep FROM tree WHERE ord = relativ_menu);
        UPDATE tree SET ord=ord+1 WHERE ord>=relativ_menu_ord;
        INSERT INTO tree (name, ord, dep) VALUES (name_menu, relativ_menu_ord, relativ_menu_dep);
    ELSIF direct=1 THEN
		relativ_menu_ord = ( SELECT MIN(ord) FROM tree WHERE ord>relativ_menu AND dep<=(SELECT dep FROM tree WHERE ord =relativ_menu) );
        relativ_menu_dep = (SELECT dep FROM tree WHERE ord = relativ_menu);
        UPDATE tree SET ord=ord+1 WHERE ord>=relativ_menu_ord;
        INSERT INTO tree (name, ord, dep) VALUES (name_menu, relativ_menu_ord, relativ_menu_dep);
    ELSIF direct=2 THEN
		relativ_menu_ord = relativ_menu;
		relativ_menu_dep = (SELECT dep FROM tree WHERE ord = relativ_menu);
        UPDATE tree SET ord=ord+1 WHERE ord>relativ_menu_ord;
        INSERT INTO tree (name, ord, dep) VALUES (name_menu, relativ_menu_ord+1, relativ_menu_dep+1);

END IF;
END;
$$;

alter procedure sp_add(integer, integer, varchar) owner to postgres;

