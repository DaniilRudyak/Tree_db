create view mainquestions(name, ord) as
SELECT tree.name,
       tree.ord
FROM tree
WHERE tree.dep = 1;

alter table mainquestions
    owner to postgres;

