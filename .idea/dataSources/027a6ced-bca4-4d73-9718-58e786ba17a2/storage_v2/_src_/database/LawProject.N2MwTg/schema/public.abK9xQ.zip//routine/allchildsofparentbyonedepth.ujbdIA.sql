create function allchildsofparentbyonedepth(inputord integer) returns SETOF tree
    language plpgsql
as
$$
BEGIN
RETURN QUERY
SELECT id, name, ord, dep, isLeaf FROM tree
                       WHERE ord >= inputord
                       AND ord < ( SELECT MIN( ord ) FROM tree 
                            WHERE ord >inputord 
                            AND dep <= ( SELECT dep FROM tree WHERE ord=inputord ) ) 
                      AND dep = (SELECT dep+1 FROM tree where ord=inputord);
END;
$$;

alter function allchildsofparentbyonedepth(integer) owner to postgres;

