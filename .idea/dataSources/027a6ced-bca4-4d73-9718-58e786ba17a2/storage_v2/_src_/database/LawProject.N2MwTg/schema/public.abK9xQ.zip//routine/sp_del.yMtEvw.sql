create procedure sp_del(inputord integer, direct integer)
    language plpgsql
as
$$
DECLARE 
min_ord INT;
max_ord INT;
count_id INT;
menu_ord INT;
menu_dep INT;
id_node_pr INT;
BEGIN
menu_ord = inputord;
menu_dep = (SELECT dep FROM tree WHERE ord = inputord);
max_ord = (SELECT MIN(ord) FROM tree WHERE ord> menu_ord AND dep<= menu_dep);
BEGIN
IF (direct=0) THEN
	DELETE FROM tree WHERE ord=inputord;
    UPDATE tree SET dep=dep-1 WHERE ord > @menu_ord AND ord < @max_ord;
    UPDATE tree SET ord=ord-1 WHERE ord > @menu_ord;
ELSIF (direct=1) THEN
	count_id = (SELECT COUNT(id) FROM tree WHERE ord >= menu_ord AND ord < max_ord);
    DELETE FROM tree WHERE ord >= menu_ord AND ord < max_ord;
    UPDATE tree SET ord=ord-count_id WHERE ord >= max_ord;
END IF;
END;
END;
$$;

alter procedure sp_del(integer, integer) owner to postgres;

