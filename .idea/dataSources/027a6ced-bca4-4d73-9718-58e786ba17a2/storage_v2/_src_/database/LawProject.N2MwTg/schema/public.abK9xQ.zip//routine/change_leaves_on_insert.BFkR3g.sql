create function change_leaves_on_insert() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE tree SET isleaf=true WHERE ord = NEW.ord;
UPDATE tree SET isleaf=false WHERE ord=(SELECT MAX(ord) FROM tree WHERE dep<NEW.dep AND ord<NEW.ord );
RETURN NEW;
END;
$$;

alter function change_leaves_on_insert() owner to postgres;

