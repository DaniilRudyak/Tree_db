create function change_leaves_on_delete() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT EXISTS(SELECT ord FROM tree WHERE dep=OLD.dep AND (ord=OLD.ord-1 OR ord=OLD.ord+1))
THEN
UPDATE tree SET isleaf=true WHERE ord=(SELECT MAX(ord) FROM tree WHERE dep=OLD.dep-1 AND ord<OLD.ord);
END IF;
RETURN OLD;
END;
$$;

alter function change_leaves_on_delete() owner to postgres;

